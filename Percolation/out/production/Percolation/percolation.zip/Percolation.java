import edu.princeton.cs.algs4.WeightedQuickUnionUF;

/**
 * Created by saurabh on 2/24/17.
 */
public class Percolation {

    private static final byte OPEN = 1;
    private static final byte FULL = 2;

    private int n;
    private int openSiteCount;
    private int lastItemPosition;
    private byte[] sites;
    private WeightedQuickUnionUF unionUF;

    public Percolation(int n) {
        if (n <= 0) throw new IllegalArgumentException();

        this.n = n;
        int totalItems = (n * n) + 2;
        lastItemPosition = totalItems - 1;

        unionUF = new WeightedQuickUnionUF(totalItems);
        sites = new byte[totalItems];

        sites[0] = FULL;
        sites[lastItemPosition] = OPEN;
    }

    public void open(int row, int col) {
        validateIndices(row, col);

        if (isOpen(row, col)) return;

        int current = xyTo1D(row, col);
        sites[current] = OPEN;
        openSiteCount++;

        if (col - 1 >= 1 && isOpen(row, col - 1)) {
            unionUF.union(current, xyTo1D(row, col - 1));
            if (isFull(row, col - 1)) sites[current] = FULL;
        }

        if (col + 1 <= n && isOpen(row, col + 1)) {
            unionUF.union(current, xyTo1D(row, col + 1));
            if (isFull(row, col + 1)) sites[current] = FULL;
        }

        if (row - 1 == 0) {
            unionUF.union(current, 0);
            sites[current] = FULL;
        } else if (isOpen(row - 1, col)) {
            unionUF.union(current, xyTo1D(row - 1, col));
            if (isFull(row - 1, col)) sites[current] = FULL;
        }

        if (row == n) {
            unionUF.union(current, lastItemPosition);
            if (sites[current] == FULL) sites[lastItemPosition] = FULL;
        } else if (isOpen(row + 1, col)) {
            unionUF.union(current, xyTo1D(row + 1, col));
            if (isFull(row + 1, col)) sites[current] = FULL;
        }

        if (sites[current] == FULL) fillNeighbours(row, col);
    }

    public boolean isOpen(int row, int col) {
        validateIndices(row, col);
        return sites[xyTo1D(row, col)] == OPEN || sites[xyTo1D(row, col)] == FULL;
    }

    public boolean isFull(int row, int col) {
        validateIndices(row, col);
        return sites[xyTo1D(row, col)] == FULL;
    }

    public int numberOfOpenSites() {
        return openSiteCount;
    }

    public boolean percolates() {
        return sites[lastItemPosition] == FULL;
    }

    private void validateIndices(int row, int col) {
        if (row < 1 || row > n || col < 1 || col > n)
            throw new IndexOutOfBoundsException();
    }

    private int xyTo1D(int row, int col) {
        return (n * (row - 1)) + col;
    }

    private void fillNeighbours(int row, int col) {

        if (col - 1 >= 1 && isOpen(row, col - 1) && !isFull(row, col - 1)) {
            sites[xyTo1D(row, col - 1)] = FULL;
            fillNeighbours(row, col - 1);
        }

        if (col + 1 <= n && isOpen(row, col + 1) && !isFull(row, col + 1)) {
            sites[xyTo1D(row, col + 1)] = FULL;
            fillNeighbours(row, col + 1);
        }

        if (row - 1 != 0 && isOpen(row - 1, col) && !isFull(row - 1, col)) {
            sites[xyTo1D(row - 1, col)] = FULL;
            fillNeighbours(row - 1, col);
        }

        if (row == n) {
            if (sites[xyTo1D(row, col)] == FULL) sites[lastItemPosition] = FULL;
        } else if (isOpen(row + 1, col) && !isFull(row + 1, col)) {
            sites[xyTo1D(row + 1, col)] = FULL;
            fillNeighbours(row + 1, col);
        }
    }
}
